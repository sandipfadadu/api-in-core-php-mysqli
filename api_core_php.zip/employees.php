<?php

    require_once './connection.php';

    $db = new dbObj();
    $connection = $db->getConnstring();
    $request_method = @$_POST['method'];    
    
    switch($request_method)
    {
        case 'get_employees':
                $id = $_POST['id'];
                get_employees($id);
                break;
        case 'insert_employee':
                insert_employee();
                break;
        case 'delete_employee':
                $id = $_POST['id'];
                delete_employee($id);
                break;
        case 'update_employee':
                $id = $_POST['id'];                
                update_employee($id);
                break;
        case 'view_books':
                $id = $_POST['id'];
                $price = $_POST['price'];
                view_books($id,$price);
                break;
        
        default:
                header("HTTP/1.0 405 Method Not Allowed");
                break;
    }
    
    function get_employees($id=0)
    {
        global $connection;
        $limit = 2;
        if(isset($_POST["page"])) 
        { 
            $page  = $_POST["page"];        
        } 
        else 
        { 
            $page=1; 
        }  
        $start_from = ($page-1) * $limit;
        $query="SELECT * FROM tbluser LIMIT $start_from, $limit";
        if($id != 0)
        {
            $query = "SELECT * FROM tbluser WHERE userId=".$id." LIMIT 1";
        }
        $response=array();
        $result=mysqli_query($connection, $query);
        while($row=  mysqli_fetch_assoc($result))
        {
            $response[]=$row;
        }
        header('Content-Type: application/json');
        echo json_encode($response);
    }
    
    function insert_employee()
    {
        global $connection;       
        $user_name = $_POST['name'];
        $user_email = $_POST['email'];
        $user_password = $_POST['password'];
        $query = "INSERT INTO tbluser SET userName ='".$user_name."',userEmail ='".$user_email."',userPassword ='".$user_password."' ";
        
        if(mysqli_query($connection, $query))
        {
            $response=array(
                    'status' => 1,
                    'status_message' =>'User Added Successfully.'
            );
        }
        else
        {
            $response=array(
                    'status' => 0,
                    'status_message' =>'User Addition Failed.'
            );
        }
        header('Content-Type: application/json');
        echo json_encode($response);        
    }
    
    function delete_employee($id)
    {
        global $connection;
        $query = "DELETE FROM tbluser WHERE userId = $id";
        if(mysqli_query($connection, $query))
        {
            $response=array(
                    'status' => 1,
                    'status_message' =>'User Deleted Successfully.'
            );
        }
        else
        {
            $response=array(
                    'status' => 0,
                    'status_message' =>'User Delete Failed.'
            );
        }
        header('Content-Type: application/json');
        echo json_encode($response);       
    }
    
    function update_employee($id)
    {
        global $connection;
        $user_name = $_POST['name'];
        $user_email = $_POST['email'];
        $user_password = $_POST['password'];
        $query = "UPDATE tbluser SET userName ='".$user_name."',userEmail ='".$user_email."',userPassword ='".$user_password."' WHERE userId = $id ";
        if(mysqli_query($connection, $query))
        {
            $response=array(
                    'status' => 1,
                    'status_message' =>'User Updated Successfully.'
            );
        }
        else
        {
            $response=array(
                    'status' => 0,
                    'status_message' =>'User Updation Failed.'
            );
        }
        header('Content-Type: application/json');
        echo json_encode($response);        
    }
    
    function view_books($id=0,$price=NULL)
    {
        global $connection;
        $limit = 3;
        if(isset($_POST["page"])) 
        { 
            $page  = $_POST["page"];        
        } 
        else 
        { 
            $page=1; 
        }  
        $start_from = ($page-1) * $limit;
        
        if($id != 0)
        {
            $query = "SELECT * FROM tbl_books WHERE id=".$id." LIMIT 1";
        }
        else if($price != NULL)
        {
            $query = "SELECT * FROM tbl_books WHERE price = ".$price." LIMIT $start_from, $limit";
        }
        else
        {
            $query="SELECT * FROM tbl_books LIMIT $start_from, $limit";
        }
        $response=array();
        $result=mysqli_query($connection, $query);
        while($row=  mysqli_fetch_assoc($result))
        {
            $response[]=$row;
        }
        header('Content-Type: application/json');
        echo json_encode($response);
    }
    
    
?>